{
	// nested_script.jsx
	// 
	// This is called by the call_nested_script.jsx script.
	
	alert("This alert is brought to you by the file nested_script.jsx.");
}
